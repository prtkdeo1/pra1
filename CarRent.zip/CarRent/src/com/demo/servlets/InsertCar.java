package com.demo.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.demo.dao.DBUtil;

/**
 * Servlet implementation class InsertCar
 */
@WebServlet("/InsertCar")
public class InsertCar extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InsertCar() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter out=response.getWriter();
		String carName=request.getParameter("carname");
		String carNumber=request.getParameter("carnumber");
		int carCapacity=Integer.parseInt(request.getParameter("carseats"));
		int carRent=Integer.parseInt(request.getParameter("carrent"));
		int carDeposit=Integer.parseInt(request.getParameter("cardeposit"));
		String carCity=request.getParameter("carcity");
		String carColor=request.getParameter("carcolor");
Connection conn=DBUtil.connect();
		
	    try {
            CallableStatement cst = conn.prepareCall("{call insertCar(?,?,?,?,?,?,?)}");

            cst.setString(1,carName);
            cst.setString(2,carNumber);
            cst.setInt(3,carCapacity);
            cst.setInt(4,carRent);
            cst.setInt(5,carDeposit);
            cst.setString(6,carCity);
       
            cst.setString(7,carColor);
            cst.execute();
            RequestDispatcher rd=request.getRequestDispatcher("InsertCar.jsp");
            out.println("<h1 align='center'>Car added successfully</h1>");
            rd.include(request, response);
            
	    	} catch (SQLException e) {
            
            e.printStackTrace();
} 
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
