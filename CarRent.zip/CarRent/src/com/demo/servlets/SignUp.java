package com.demo.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.demo.dao.DBUtil;

/**
 * Servlet implementation class SignUp
 */
@WebServlet("/SignUp")
public class SignUp extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SignUp() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		String firstname=request.getParameter("firstname");
		String lastname=request.getParameter("lastname");
		String date123=request.getParameter("DOB");
		String gender=request.getParameter("gender");
		String city=request.getParameter("city");
		int pin=Integer.parseInt(request.getParameter("pin"));
		String mobile=request.getParameter("mobile");
		String email=request.getParameter("email");
		String upassword=request.getParameter("upassword");
		String security=request.getParameter("security");
		
		Connection conn=DBUtil.connect();
		
	    try {
            CallableStatement cst = conn.prepareCall("{call insertUser(?,?,?,?,?,?,?,?,?,?)}");

            cst.setString(1,firstname);
            cst.setString(2,lastname);
            cst.setString(3,date123);
            cst.setString(4,gender);
            cst.setString(5,city);
            cst.setInt(6,pin);
            cst.setString(7,mobile);
            cst.setString(8,email);
            cst.setString(9,upassword);
            cst.setString(10,security);
                                                                                            
            cst.execute();
            out.println("<h1>Registration successfully completed</h1>");
            
	    	} catch (SQLException e) {
            
            e.printStackTrace();
} 
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		
		doGet(request,response);
		

		
		
	}

}
